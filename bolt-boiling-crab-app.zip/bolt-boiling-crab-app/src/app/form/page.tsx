import dynamic from 'next/dynamic';

// Dynamically import ManagerForm to ensure client rendering only
const ManagerForm = dynamic(() => import('@/components/ManagerForm'), { ssr: false });

export default function FormPage() {
  return <ManagerForm />;
}