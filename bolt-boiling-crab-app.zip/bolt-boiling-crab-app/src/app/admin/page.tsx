"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Admin landing page with passcode gate. Once passcode is entered correctly,
 * it's stored in sessionStorage and reused for API calls.
 */
export default function AdminHome() {
  const router = useRouter();
  const [passcode, setPasscode] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem('adminPasscode');
    if (saved) {
      setIsAuthorized(true);
    }
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!passcode) return;
    // Simple client-side check: we optimistically allow and store. The server routes will verify.
    sessionStorage.setItem('adminPasscode', passcode);
    setIsAuthorized(true);
  }

  if (!isAuthorized) {
    return (
      <div className="max-w-sm mx-auto mt-24 p-6 bg-white rounded shadow">
        <h1 className="text-xl font-semibold mb-4 text-center">Admin Access</h1>
        {error && <p className="text-red-600 mb-2">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" htmlFor="passcode">Enter Passcode</label>
            <input
              id="passcode"
              type="password"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              className="w-full border rounded px-3 py-2"
              required
            />
          </div>
          <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700">
            Submit
          </button>
        </form>
      </div>
    );
  }

  // If authorized, show navigation
  return (
    <div className="max-w-md mx-auto mt-12 space-y-4 p-4">
      <h1 className="text-2xl font-semibold text-center">Admin Panel</h1>
      <div className="flex flex-col gap-3 mt-6">
        <button onClick={() => router.push('/admin/redemptions')} className="p-3 bg-white rounded shadow hover:bg-gray-50 text-left">
          Redemptions
        </button>
        <button onClick={() => router.push('/admin/staff')} className="p-3 bg-white rounded shadow hover:bg-gray-50 text-left">
          Staff
        </button>
        <button onClick={() => router.push('/admin/prizes')} className="p-3 bg-white rounded shadow hover:bg-gray-50 text-left">
          Prizes
        </button>
        <button onClick={() => router.push('/admin/qr')} className="p-3 bg-white rounded shadow hover:bg-gray-50 text-left">
          QR & Links
        </button>
      </div>
    </div>
  );
}