"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface Prize {
  id: string;
  label: string;
  is_active: boolean;
}

export default function PrizesAdmin() {
  const router = useRouter();
  const [prizes, setPrizes] = useState<Prize[]>([]);
  const [newLabel, setNewLabel] = useState('');
  const passcode = typeof window !== 'undefined' ? sessionStorage.getItem('adminPasscode') || '' : '';

  useEffect(() => {
    if (!passcode) {
      router.push('/admin');
      return;
    }
    fetchPrizes();
  }, []);

  async function fetchPrizes() {
    const res = await fetch('/api/prizes/list');
    const json = await res.json();
    setPrizes(json.data || []);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newLabel) return;
    await fetch('/api/prizes/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-passcode': passcode,
      },
      body: JSON.stringify({ label: newLabel }),
    });
    setNewLabel('');
    fetchPrizes();
  }

  async function toggleActive(id: string, current: boolean) {
    await fetch('/api/prizes/update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-passcode': passcode,
      },
      body: JSON.stringify({ id, is_active: !current }),
    });
    fetchPrizes();
  }

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Prizes</h1>
      <form onSubmit={handleCreate} className="mb-4 flex gap-2">
        <input
          type="text"
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          placeholder="Prize label"
          className="flex-1 border rounded px-3 py-2"
        />
        <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          Add
        </button>
      </form>
      <div className="bg-white rounded shadow">
        <table className="min-w-full">
          <thead className="bg-gray-100 text-sm text-gray-700">
            <tr>
              <th className="px-4 py-2 text-left">Label</th>
              <th className="px-4 py-2 text-left">Active</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {prizes.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="px-4 py-2">{p.label}</td>
                <td className="px-4 py-2">{p.is_active ? 'Yes' : 'No'}</td>
                <td className="px-4 py-2 text-right">
                  <button
                    onClick={() => toggleActive(p.id, p.is_active)}
                    className="text-sm text-indigo-600 underline"
                  >
                    {p.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}