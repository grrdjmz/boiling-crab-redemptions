"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface Staff { id: string; name: string; }
interface Prize { id: string; label: string; }
interface RedemptionView {
  id: string;
  staff_id: string;
  prize_id: string;
  staff_name: string;
  prize_label: string;
  redeemed_at: string;
  manager: string | null;
  created_at: string;
}

export default function RedemptionsAdmin() {
  const router = useRouter();
  const [staffOptions, setStaffOptions] = useState<Staff[]>([]);
  const [prizeOptions, setPrizeOptions] = useState<Prize[]>([]);
  const [data, setData] = useState<RedemptionView[]>([]);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [staffId, setStaffId] = useState('');
  const [prizeId, setPrizeId] = useState('');
  const [loading, setLoading] = useState(false);
  const passcode = typeof window !== 'undefined' ? sessionStorage.getItem('adminPasscode') || '' : '';

  useEffect(() => {
    if (!passcode) {
      router.push('/admin');
      return;
    }
    async function loadFilterData() {
      try {
        const [staffRes, prizeRes] = await Promise.all([
          fetch('/api/staff/list'),
          fetch('/api/prizes/list'),
        ]);
        const staffJson = await staffRes.json();
        const prizeJson = await prizeRes.json();
        setStaffOptions(staffJson.data || []);
        setPrizeOptions(prizeJson.data || []);
      } catch (e) {
        console.error(e);
      }
    }
    loadFilterData();
    // Load initial data
    refreshData();
  }, []);

  async function refreshData() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (fromDate) params.set('from', fromDate);
      if (toDate) params.set('to', toDate);
      if (staffId) params.set('staff', staffId);
      if (prizeId) params.set('prize', prizeId);
      const res = await fetch(`/api/redemptions/list?${params.toString()}`, {
        headers: { 'x-admin-passcode': passcode },
      });
      if (!res.ok) {
        console.error('Failed to load redemptions');
        setData([]);
      } else {
        const json = await res.json();
        setData(json.data || []);
      }
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  }

  async function handleExport() {
    const params = new URLSearchParams();
    if (fromDate) params.set('from', fromDate);
    if (toDate) params.set('to', toDate);
    const res = await fetch(`/api/redemptions/export?${params.toString()}`, {
      headers: { 'x-admin-passcode': passcode },
    });
    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'redemptions.csv';
      a.click();
      window.URL.revokeObjectURL(url);
    }
  }

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Redemptions</h1>
      <div className="bg-white p-4 rounded shadow mb-4 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1" htmlFor="from">From</label>
            <input id="from" type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="w-full border rounded px-2 py-1" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" htmlFor="to">To</label>
            <input id="to" type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="w-full border rounded px-2 py-1" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" htmlFor="staff-filter">Staff</label>
            <select id="staff-filter" value={staffId} onChange={(e) => setStaffId(e.target.value)} className="w-full border rounded px-2 py-1">
              <option value="">All</option>
              {staffOptions.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" htmlFor="prize-filter">Prize</label>
            <select id="prize-filter" value={prizeId} onChange={(e) => setPrizeId(e.target.value)} className="w-full border rounded px-2 py-1">
              <option value="">All</option>
              {prizeOptions.map((p) => (
                <option key={p.id} value={p.id}>{p.label}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={refreshData} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Apply</button>
          <button onClick={handleExport} className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">Export CSV</button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded shadow">
          <thead>
            <tr className="bg-gray-100 text-gray-700 text-sm">
              <th className="px-4 py-2 text-left">Date</th>
              <th className="px-4 py-2 text-left">Staff</th>
              <th className="px-4 py-2 text-left">Prize</th>
              <th className="px-4 py-2 text-left">Manager</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={4} className="text-center p-4">Loading...</td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={4} className="text-center p-4">No redemptions found.</td></tr>
            ) : (
              data.map((row) => (
                <tr key={row.id} className="border-t">
                  <td className="px-4 py-2">{row.redeemed_at}</td>
                  <td className="px-4 py-2">{row.staff_name}</td>
                  <td className="px-4 py-2">{row.prize_label}</td>
                  <td className="px-4 py-2">{row.manager || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}