"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function QRAdmin() {
  const router = useRouter();
  const [qrSrc, setQrSrc] = useState<string | null>(null);
  const passcode = typeof window !== 'undefined' ? sessionStorage.getItem('adminPasscode') || '' : '';

  useEffect(() => {
    if (!passcode) {
      router.push('/admin');
      return;
    }
    async function loadQr() {
      const res = await fetch('/api/qr');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setQrSrc(url);
    }
    loadQr();
  }, []);

  function download() {
    if (!qrSrc) return;
    const link = document.createElement('a');
    link.href = qrSrc;
    link.download = 'form-qr.png';
    link.click();
  }

  const formUrl = typeof window !== 'undefined' ? `${window.location.origin}/form` : '/form';

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-semibold mb-4">QR & Links</h1>
      <p className="mb-2">Share this link with managers to access the redemption form:</p>
      <a href={formUrl} className="text-indigo-600 underline break-all" target="_blank" rel="noopener noreferrer">{formUrl}</a>
      <div className="mt-6 flex flex-col items-center gap-4">
        {qrSrc ? (
          <img src={qrSrc} alt="QR Code" className="w-48 h-48" />
        ) : (
          <p>Loading QR code...</p>
        )}
        <button onClick={download} className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Download PNG</button>
      </div>
    </div>
  );
}