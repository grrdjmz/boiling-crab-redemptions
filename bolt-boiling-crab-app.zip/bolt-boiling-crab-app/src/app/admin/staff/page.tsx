"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface Staff {
  id: string;
  name: string;
  is_active: boolean;
}

export default function StaffAdmin() {
  const router = useRouter();
  const [staff, setStaff] = useState<Staff[]>([]);
  const [newName, setNewName] = useState('');
  const passcode = typeof window !== 'undefined' ? sessionStorage.getItem('adminPasscode') || '' : '';

  useEffect(() => {
    if (!passcode) {
      router.push('/admin');
      return;
    }
    fetchStaff();
  }, []);

  async function fetchStaff() {
    const res = await fetch('/api/staff/list');
    const json = await res.json();
    setStaff(json.data || []);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newName) return;
    await fetch('/api/staff/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-passcode': passcode,
      },
      body: JSON.stringify({ name: newName }),
    });
    setNewName('');
    fetchStaff();
  }

  async function toggleActive(id: string, current: boolean) {
    await fetch('/api/staff/update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-passcode': passcode,
      },
      body: JSON.stringify({ id, is_active: !current }),
    });
    fetchStaff();
  }

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Staff</h1>
      <form onSubmit={handleCreate} className="mb-4 flex gap-2">
        <input
          type="text"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="Staff name"
          className="flex-1 border rounded px-3 py-2"
        />
        <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
          Add
        </button>
      </form>
      <div className="bg-white rounded shadow">
        <table className="min-w-full">
          <thead className="bg-gray-100 text-sm text-gray-700">
            <tr>
              <th className="px-4 py-2 text-left">Name</th>
              <th className="px-4 py-2 text-left">Active</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {staff.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="px-4 py-2">{s.name}</td>
                <td className="px-4 py-2">{s.is_active ? 'Yes' : 'No'}</td>
                <td className="px-4 py-2 text-right">
                  <button
                    onClick={() => toggleActive(s.id, s.is_active)}
                    className="text-sm text-indigo-600 underline"
                  >
                    {s.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}