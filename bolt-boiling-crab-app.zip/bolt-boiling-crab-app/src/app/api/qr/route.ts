import { NextResponse } from 'next/server';
import QRCode from 'qrcode';

export async function GET() {
  try {
    // Determine host from env or default to relative path
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || '';
    const target = `${baseUrl}/form`;
    const buffer: Buffer = await QRCode.toBuffer(target, { type: 'png' });
    return new Response(buffer, {
      headers: {
        'Content-Type': 'image/png',
        'Content-Disposition': 'inline; filename="qr.png"',
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Failed to generate QR' }, { status: 500 });
  }
}