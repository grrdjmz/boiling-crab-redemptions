import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/lib/supabase';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { staffId, prizeId, redeemedAt, manager } = body;
    if (!staffId || !prizeId || !redeemedAt) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }
    const supabase = getSupabaseClient(true); // service role
    const { data, error } = await supabase.from('redemptions').insert({
      staff_id: staffId,
      prize_id: prizeId,
      redeemed_at: redeemedAt,
      manager: manager || null,
    }).select();
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    return NextResponse.json({ data }, { status: 200 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Unknown error' }, { status: 500 });
  }
}