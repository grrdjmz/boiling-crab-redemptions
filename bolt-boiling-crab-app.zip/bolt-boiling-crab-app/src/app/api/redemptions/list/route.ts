import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/lib/supabase';
import { verifyAdminPasscode } from '@/lib/adminAuth';

export async function GET(request: Request) {
  // verify admin passcode
  if (!verifyAdminPasscode(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const { searchParams } = new URL(request.url);
  const from = searchParams.get('from');
  const to = searchParams.get('to');
  const staff = searchParams.get('staff');
  const prize = searchParams.get('prize');
  const supabase = getSupabaseClient(true);
  let query = supabase.from('redemptions_view').select('*');
  if (from) query = query.gte('redeemed_at', from);
  if (to) query = query.lte('redeemed_at', to);
  if (staff) query = query.eq('staff_id', staff);
  if (prize) query = query.eq('prize_id', prize);
  const { data, error } = await query;
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  return NextResponse.json({ data }, { status: 200 });
}