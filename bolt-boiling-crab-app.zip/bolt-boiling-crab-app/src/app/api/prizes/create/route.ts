import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/lib/supabase';
import { verifyAdminPasscode } from '@/lib/adminAuth';

export async function POST(request: Request) {
  if (!verifyAdminPasscode(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await request.json();
  const { label } = body;
  if (!label) {
    return NextResponse.json({ error: 'Label is required' }, { status: 400 });
  }
  const supabase = getSupabaseClient(true);
  const { data, error } = await supabase.from('prizes').insert({ label }).select();
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  return NextResponse.json({ data }, { status: 200 });
}