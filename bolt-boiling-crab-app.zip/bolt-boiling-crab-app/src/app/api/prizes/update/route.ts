import { NextResponse } from 'next/server';
import { getSupabaseClient } from '@/lib/supabase';
import { verifyAdminPasscode } from '@/lib/adminAuth';

export async function POST(request: Request) {
  if (!verifyAdminPasscode(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await request.json();
  const { id, label, is_active } = body;
  if (!id) {
    return NextResponse.json({ error: 'ID is required' }, { status: 400 });
  }
  const updateData: any = {};
  if (label !== undefined) updateData.label = label;
  if (is_active !== undefined) updateData.is_active = is_active;
  const supabase = getSupabaseClient(true);
  const { data, error } = await supabase.from('prizes').update(updateData).eq('id', id).select();
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  return NextResponse.json({ data }, { status: 200 });
}