import '@/app/globals.css';
import { Inter } from 'next/font/google';
import React from 'react';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Boiling Crab Prize Redemption',
  description: 'Manager prize redemption form for The Boiling Crab — K St (Sacramento).',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen text-gray-900 bg-gray-50`}>{children}</body>
    </html>
  );
}